def helTallDiv(x,y):
    num = x//y
    return num

print("Heltallsdivisjon av 5//4 er: ", helTallDiv(5,4))

def squared(x):
    num = x**2
    return num
print("Kvadratet av 5 er: ", squared(5))

#det fører ikke til problemer fordi variablene er lokale