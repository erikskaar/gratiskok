#Kodesnutt 1:

#cake er called før den er definert.


#Kodesnutt 2:

#cupcake er kun lokal og dermed ikke definert i cakes()


#Kodesnutt 3:

#cakes() blir aldri kalt, dermed har det ingenting å si om cake ikke er definert