def sikSak():
    print()                                         
    print("**  **  **  **  **  **  **  **  **")     
    print("  **  **  **  **  **  **  **  **")       
    print()                                         

print("Data fra spørreundersøkelse")
sikSak()
print("Del 1: ... div. data her, ikke vist")
sikSak()
print("Del 2: ... mer data ...")
sikSak()                                      ##
print("Del 3: ... enda mer data ...")
sikSak()                                       ##
print("Del 4: ... ytterligere data ...")
sikSak()