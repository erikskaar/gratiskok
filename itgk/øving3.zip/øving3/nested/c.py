x=1
y=1
for x in range(11):
    for y in range(11):
        print(x*y, end='')
        print()
