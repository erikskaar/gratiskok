time = 0
minutt = 0

for time in range(24):
    for minutt in range(60):
        print(str(time) + ":" + str(minutt))
