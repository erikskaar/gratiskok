for x in range(5):
    print(x+1)
