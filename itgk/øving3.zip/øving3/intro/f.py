for x in range(15):
    print(15-x)
