i = 0
adj = input("Beskriv deg selv med et adjektiv? ")
while adj!="":
    print("Hah, du", adj + "!? Jeg er mye", adj + "ere!")
    adj = input("Beskriv deg selv med et adjektiv? ")
    i += 1  # øker i med 1

print("Takk for nå")
