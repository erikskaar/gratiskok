sum = 0
for x in range(7):
    heltall = int(input("Skriv inn et heltall:"))
    sum = int(sum + heltall)
print(sum)
