sum = 1
x=1
while sum<1000:
    x+=1
    sum = sum*x
print(sum)
