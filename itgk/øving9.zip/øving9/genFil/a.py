def write_to_file(data):
    f = open('my_file.txt', 'w')
    f.write(data)
    f.close

write_to_file("ayylmao")