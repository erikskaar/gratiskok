my_family = {}
def add_family_role(role, name):
    my_family[role] = name
    return my_family
add_family_role('far', 'Bob')
add_family_role('bror', 'Arne')
print(my_family)

