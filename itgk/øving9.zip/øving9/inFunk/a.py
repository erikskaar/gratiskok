#Dersom man skriver print(scores['Amanda']) får man ut [88, 92, 100]

#Dersom man skriver print(scores['Amanda'][2]) får man ut 100