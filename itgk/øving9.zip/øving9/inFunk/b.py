fruit = {}

fruit['Appelsin'] = 10
fruit['Eple'] = 12
fruit['Pære'] = 5