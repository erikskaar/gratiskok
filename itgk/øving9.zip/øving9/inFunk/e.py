fruit = {'bananer':0, 'druer':1}
print(fruit)
if 'bananer' in fruit:
    del fruit['bananer']
print(fruit)
