fruit = {}

fruit['Appelsin'] = 10
fruit['Eple'] = 12
fruit['Pære'] = 5

fruit['Tomat'] = 3
fruit['Agurk'] = 2

del fruit['Appelsin'], fruit['Eple'], fruit['Pære']

print(fruit['Tomat'], fruit['Agurk'])