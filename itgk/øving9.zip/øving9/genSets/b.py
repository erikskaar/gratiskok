my_set = set()

for i in range(20):
    if i%2!=0:
        my_set.add(i)

print(my_set)