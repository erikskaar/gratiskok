def removeDuplicates(lst):
    return list(set(lst))

print(removeDuplicates([1,3,5,2,3,7]))