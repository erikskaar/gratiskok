my_first_list = [1,2,3,4,5,6]
my_first_list[4] = "pluss"
print(my_first_list)