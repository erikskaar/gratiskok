my_first_list = [1,2,3,4,5,6]
print(my_first_list)