number_list = []
for x in range (100):
    number_list.append(x)
print(number_list)