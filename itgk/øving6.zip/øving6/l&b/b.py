def average(list):
    return sum(list)/len(list)
newList = [1,3,5,7,9,11]
print(average(newList))