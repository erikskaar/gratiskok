print("Heihei, jeg vil visst ikke kompilere jeg :(")
print("Halla, så \"bra\" du ser ut i dag")
print('Hei på deg')
print ("Er ikke dette gøy?")
