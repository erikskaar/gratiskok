print('''Noen barn sto og hang ved lekeplassen.
Diskusjonstemaet deres var noe uventet.
- Hvorfor heter'e "Python"?
- Var'e slanger som laget det? - Nei, Guido van Rossum.
- Likte slanger kanskje da? - Nei, digga "Monty Python".
- Hva er det? Et fjell?
- Nei, engelsk komigruppe. Begynte i '69.
- Wow! Var'e fremdeles dinosaurer da?''')
