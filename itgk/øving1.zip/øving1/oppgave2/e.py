#I oppgave b brukte jeg print for å få programmet til å skrive ut forskjellige linjer med tekst, og brukte kommaer for å separere tallene og teksten
#I oppgave c brukte jeg backslash \ for å forhindre at fnuttene ble brukt for å avslutte stringen
#print('Hei")
