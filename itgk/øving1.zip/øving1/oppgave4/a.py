print(input("Navn? "), "- Kult navn!")
print(input("Favorittfag?"), "- interessant!")
