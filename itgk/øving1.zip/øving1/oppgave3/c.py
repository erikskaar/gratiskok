import math
# importerer fra math-biblioteket

print("|-8|, dvs. absoluttverdien til -8, er", abs(-8))
print(2.544, "avrundet til helt tall er", round(2.544))
print("Funksjonen int() derimot bare kutter vekk desimalene:", int(2.544) )
print(2.544, "avrundet til to desimaler er", round(2.544, 2))
print("Kvadratroten til", 10, "er", math.sqrt(10))
print("En sirkel med radius 7 har omkrets", 7*2*math.pi)
print("En sirkel med radius 7 har areal", 7*7*math.pi)
