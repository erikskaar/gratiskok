#Kodesnutt 1
#streng = "I Want Cake"
#streng[7:] = "Cupcake"
#print(streng)
 
#Du kan ikke bare legge til deler i en streng på denne måten.

#Kodesnutt 2
#streng = "I Want Cake"
#streng = streng[-4:100:]
#print(streng)

#Her er ingenting feil ettersom at om du har høyere enn lengden på strengen som sluttdestinasjon vil den fortsatt fungere helt fint.

##Kodesnutt 3 
#streng = "I Want Cake"
#streng = streng[]
#print(streng)

#Du kan ikke bare sette en variabel til å være en udefinert del av en streng.