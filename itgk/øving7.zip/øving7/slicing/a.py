def sliceTime(string):
    return string[::4]

myString = "AyylBaoaC sdDaskEdnaskd asdksaldsa"
print(sliceTime(myString))