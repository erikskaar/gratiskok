
def iterate(word):
    for character in word:
      print(character)

iterate("ayylmao")