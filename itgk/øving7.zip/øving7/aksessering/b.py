def iterate(word, count):
      if(count<=len(word)):
            return word[count]
      else:
            return "q"


print(iterate("ayylmao", 6))