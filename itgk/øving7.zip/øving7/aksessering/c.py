def iterate(word):
    return len(word)-1

print(iterate("The Way of Kings"))