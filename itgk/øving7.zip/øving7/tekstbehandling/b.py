def behandler(string,char):
    string = string.split(char)
    return string


streng = "Hakuna Matata"
karakter = 'a'
print(behandler(streng, karakter))