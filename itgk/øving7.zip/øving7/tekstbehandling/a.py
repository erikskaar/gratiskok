def behandler(string):
    string = string.strip()
    string = string.upper()
    return string

streng = " \n  The Sky's Awake So I'm Awake  \t  "
print(behandler(streng))