def concate(s1,s2):
    return s1 + " " + s2

print(concate("ayylmao", "itgk"))