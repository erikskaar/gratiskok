alder = int(input("Skriv inn din alder:\n"))
if alder>=18:
    print("Du kan stemme:)")
elif alder<18:
    print("Du kan ikke stemme ennå")
