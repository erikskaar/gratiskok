antDager = input("Hvor mange dager er det til du skal reise?\n")
if int(antDager)>=14:
    print("Du kan få minipris: 199,-")
elif int(antDager)<=13:
    print("For sent for minipris; fullpris 440,-")
