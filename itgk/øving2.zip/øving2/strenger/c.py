#kodesnutt 1 vil skrive:
#"k er større enn b"

#Kodesnutt 2 vil skrive:
#Los Angeles
#New York

#Kodesnutt 3 vil skrive:
#druer
