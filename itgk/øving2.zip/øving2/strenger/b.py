navn1 = str(input("Skriv inn navn 1\n"))
navn2 = str(input("Skriv inn navn 2\n"))
if navn1 > navn2:
    print("Under følger navnene i alfabetisk rekkefølge:")
    print(navn2)
    print(navn1)
else:
    print("Under følger navnene i alfabetisk rekkefølge:")
    print(navn1)
    print(navn2)
